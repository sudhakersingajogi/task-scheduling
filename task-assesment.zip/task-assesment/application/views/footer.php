</section>
  <!-- container section start -->
<script>
var base_url = "<?PHP echo base_url();?>";
</script>
    <!-- javascripts -->
    <script src="resources/template-assets/js/jquery.js"></script>
	<script src="resources/template-assets/js/jquery-ui-1.10.4.min.js"></script>
    <script src="resources/template-assets/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="resources/template-assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <!-- bootstrap -->
    <script src="resources/template-assets/js/bootstrap.min.js"></script>

    <!-- nice scroll -->
    <script src="resources/template-assets/js/jquery.scrollTo.min.js"></script>
    <script src="resources/template-assets/js/jquery.nicescroll.js" type="text/javascript"></script>

   
    <!--custome script for all page-->
    <script src="resources/template-assets/js/scripts.js"></script>
    
    <script src="resources/custom-assests/js/scripts.js"></script>
	<script  src="resources/custom-assests/js/jquery-ui.js"></script>

<script>
$(document).ready(function()
{
	$( "#bookingdate" ).datepicker({
										
										dateFormat:"d-mm-yy",
										minDate: new Date()
									});
	$( ".bookingdate" ).datepicker({
									dateFormat:"d-mm-yy",
									 minDate: new Date()
									});	
	


});


</script>
  </body>
</html>
