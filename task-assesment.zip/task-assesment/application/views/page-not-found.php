
<section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
			  <div class="row">
				<div class="col-lg-12">
					
					<ol class="breadcrumb">
						
						<li><i class="fa fa-laptop"></i>Page not found</li>						  	
					</ol>
				</div>
			</div>
              
            <div class="row">
				<div class="page-404">
    <p class="text-404">404</p>

    <h2>Sorry</h2>
    <p>Data not found on this request<a href="<?PHP echo base_url($routeto)?>">Return Home</a></p>
  </div>
			</div><!--/.row-->
		
			
             
            
		  
          

          </section>
          
          
      </section>